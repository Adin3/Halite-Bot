<br />
<div align="center">
  <img src="https://i.imgur.com/2QUSNa2.png" alt="If the image is not loading, imagine the logo here :)" width=100% height=100%>

  <p align="center">
    <br> <br>
    Bot creat pentru jocul Halite 1
    <br>
    Proiect creat pe perioada materiei PA UPB.
    
</div>

<br>
<br>
<br>

